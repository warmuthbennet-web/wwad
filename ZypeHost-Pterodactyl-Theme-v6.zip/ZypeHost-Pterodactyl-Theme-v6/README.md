# ZypeHost Pterodactyl Theme v6

Fixes the duplicated card / duplicated Impressum-Rechte-Copyright bug from
earlier versions and adds an animated, coupled background.

## Was ist neu ggü. v5

- `install.sh` setzt `wrapper.blade.php` und `LoginFormContainer.tsx` per
  `git checkout` auf den Original-Zustand zurück, **bevor** das neue Theme
  angewendet wird. Dadurch kann nichts von v2/v3/v4/v5 mehr doppelt
  übrig bleiben, egal welche Marker damals genutzt wurden.
- Fallback ohne Git: robustere Marker-Bereinigung als vorher.
- `reset.sh` (neu): setzt die Login-Seite nur zurück, ohne das neue Theme
  zu installieren — falls du erstmal nur aufräumen willst.
- Hintergrund und die Glow-Punkte sind jetzt eine gekoppelte, animierte
  Szene (langsame Bewegung), statt statischer Layer.
- Logo, Karte und Footer kommen nur noch einmal vor.
- `install.sh` leert jetzt automatisch den Cache und baut das Frontend
  selbst (`yarn build:production`), kein manueller Schritt mehr nötig.

## Impressum

Die Platzhalter (Name/Firma, Adresse, E-Mail) in `theme/LoginFormContainer.tsx`
sind noch nicht ausgefüllt — das kann ich nicht für dich erfinden, das muss
mit deinen echten Angaben rein, sonst ist es rechtlich nicht gültig. Suche
nach `HIER DEINEN NAMEN` in der Datei.

## Installation über GitHub

1. Lade diesen Ordner (bzw. das zip) in dein eigenes GitHub-Repo hoch.
2. Auf dem Server:

```bash
cd /root && rm -rf ZypeHost-Theme && \
git clone https://github.com/<DEIN-USER>/<DEIN-REPO>.git ZypeHost-Theme && \
cd ZypeHost-Theme/ZypeHost-Pterodactyl-Theme-v6 && \
chmod +x install.sh reset.sh uninstall.sh && \
bash install.sh
```

Ersetze `<DEIN-USER>/<DEIN-REPO>` mit deinem eigenen Repo-Pfad.

### Nur aufräumen (alte Designs entfernen, ohne neu zu installieren)

```bash
cd /root/ZypeHost-Theme/ZypeHost-Pterodactyl-Theme-v6 && bash reset.sh
```

### Direkt vom Zip auf dem Server (ohne GitHub)

```bash
cd /root && rm -rf ZypeHost-Theme && mkdir ZypeHost-Theme && cd ZypeHost-Theme && \
unzip -o /pfad/zu/ZypeHost-Pterodactyl-Theme-v6.zip && \
cd ZypeHost-Pterodactyl-Theme-v6 && \
chmod +x install.sh reset.sh uninstall.sh && \
bash install.sh
```

## Rückgängig machen

```bash
bash uninstall.sh
```
