#!/usr/bin/env bash
# ZypeHost Pterodactyl Theme v10 — installer
# v10 adds: swapped login card layout (form left / logo right), a real
# Impressum instead of placeholders, a redesigned brand mark, and a new
# "Z" favicon set that replaces Pterodactyl's default falcon favicon.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
FAVICON_SRC="$ROOT_DIR/theme/public/favicons"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v10-$STAMP"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost v10] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost v10] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$TARGET" ]] || fail "LoginFormContainer.tsx nicht gefunden: $TARGET"
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-logo.png" ]] || fail "zypehost-logo.png fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-icon.png" ]] || fail "zypehost-icon.png fehlt im Theme-Ordner"
[[ -d "$FAVICON_SRC" ]] || fail "favicons-Ordner fehlt im Theme-Ordner"

mkdir -p "$BACKUP"
cp -a "$TARGET" "$BACKUP/LoginFormContainer.tsx"
[[ -f "$WRAPPER" ]] && cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php" || true
[[ -d "$FAVICON_DIR" ]] && cp -a "$FAVICON_DIR" "$BACKUP/favicons" || true
[[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env" || true
info "Backup gespeichert unter: $BACKUP"

# --- Step 1: HARD RESET so nothing from v2/v3/v4/v5 can survive -----------
cd "$PANEL_DIR"
if [[ -d .git ]]; then
    info "Git-Repo erkannt — setze wrapper.blade.php und LoginFormContainer.tsx auf den Original-Stand zurück..."
    git checkout -- \
        "resources/views/templates/wrapper.blade.php" \
        "resources/scripts/components/auth/LoginFormContainer.tsx" 2>/dev/null || \
        info "Hinweis: git checkout konnte eine der Dateien nicht zurücksetzen (evtl. schon sauber)."
else
    info "Kein Git-Repo gefunden — entferne alte ZypeHost-Marker per Textsuche stattdessen."
    if [[ -f "$WRAPPER" ]]; then
        python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
# strip every historical marker pair, whatever version made it
for marker in ('ZYPEHOST_V6_ASSETS', 'ZYPEHOST_V5_ASSETS', 'ZYPEHOST_V4_ASSETS', 'ZYPEHOST_V3_ASSETS', 'ZYPEHOST_V2_ASSETS'):
    s = re.sub(r'<!--\s*' + re.escape(marker) + r'\s*-->.*?<!--\s*/' + re.escape(marker) + r'\s*-->\s*', '', s, flags=re.S)
# safety net: also strip any leftover comment block that just mentions zypehost
s = re.sub(r'<!--[^>]*zypehost[^>]*-->.*?<!--[^>]*/[^>]*zypehost[^>]*-->\s*', '', s, flags=re.S | re.I)
p.write_text(s, encoding='utf-8')
PY
    fi
fi

# --- Step 2: wipe old theme assets completely, then lay down fresh ones ---
rm -rf "$ASSET_DIR"
mkdir -p "$ASSET_DIR"
cp -f "$SRC/background.jpeg" "$ASSET_DIR/background.jpeg"
cp -f "$SRC/zypehost-logo.png" "$ASSET_DIR/zypehost-logo.png"
cp -f "$SRC/zypehost-icon.png" "$ASSET_DIR/zypehost-icon.png"

# --- Step 3: write the new single-card component (full overwrite) --------
cp -f "$ROOT_DIR/theme/LoginFormContainer.tsx" "$TARGET"

# --- Step 3b: replace the default Pterodactyl favicon with the ZypeHost
#     "Z" mark (same filenames, so no blade/template edits are needed) ----
mkdir -p "$FAVICON_DIR"
cp -f "$FAVICON_SRC"/*.png "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$PANEL_DIR/public/favicon.ico" 2>/dev/null || true
info "Favicon ersetzt (Falke -> Z)."

# --- Step 4: clear cache + rebuild frontend automatically -----------------
info "Leere Cache und baue das Frontend neu (das kann ein paar Minuten dauern)..."
php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
if command -v yarn >/dev/null 2>&1; then
    yarn build:production
else
    fail "yarn wurde nicht gefunden — bitte 'yarn build:production' manuell im Panel-Verzeichnis ausführen."
fi

info "Fertig. ZypeHost v10 ist installiert — Formular links, Logo rechts, echtes Impressum, neues Z-Favicon."
info ""
info "Wichtig zum Favicon: Browser cachen Favicons besonders hartnäckig (unabhängig"
info "vom normalen Seiten-Cache). Falls im Tab weiter der alte Vogel zu sehen ist,"
info "obwohl die Datei hier auf dem Server jetzt richtig liegt:"
info "  - Tab komplett schliessen und neu öffnen (nicht nur neu laden)"
info "  - oder im Privat-/Inkognito-Fenster testen"
info "  - oder Browser-Cache für die Domain gezielt leeren"
info "Server-seitig geprueft werden kann das mit:"
info "  ls -la $FAVICON_DIR"
