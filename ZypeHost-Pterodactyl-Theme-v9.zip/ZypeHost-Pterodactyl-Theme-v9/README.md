# ZypeHost Pterodactyl Theme v9

Fixes the duplicated card / duplicated Impressum-Rechte-Copyright bug from
earlier versions and adds an animated, coupled background.

## Was ist neu ggü. v9 (v8→v9)

- **Echtes Logo:** Maskottchen-Grafik im LogoPane ersetzt durch das echte
  ZypeHost-Logo (Schriftzug + Claim "Fast . Reliable . Modern Hosting").
- **Echtes Icon überall:** Favicon UND das kleine Badge in der Kopfzeile
  der Login-Seite nutzen jetzt den echten Z-Schwung aus dem Logo statt
  eines generischen Buchstabens.

## Was ist neu ggü. v7

- **Layout getauscht:** Login-Formular jetzt links, Logo/Mascot-Pane rechts.
- **Echtes Impressum** statt Platzhaltertext (Angaben gemäß § 5 DDG,
  Kontakt, Verantwortlich nach § 18 Abs. 2 MStV).
- **Neuer Brand-Mark:** kleines "Z"-Badge statt des generischen Punkts.
- **Neues Favicon:** ersetzt das Standard-Pterodactyl-Falken-Favicon durch
  ein eigenes "Z"-Icon (favicon.ico, 16/32px, apple-touch-icon,
  android-chrome 192/512) — wird automatisch mitinstalliert.
- Feiner Farbverlaufsstreifen oben auf der Login-Karte, dezente Hover-
  Animation auf dem Logo.

## Was war neu ggü. v6

- **Layout-Bug behoben:** Username-Feld, Passwort-Label und Login-Button
  haben sich vorher überlappt (Felder standen nebeneinander statt
  untereinander). Das Formular ist jetzt hart auf eine Spalte gezwungen,
  unabhängig davon, welches CSS das Panel selbst mitbringt.
- Labels stehen jetzt zuverlässig **über** dem jeweiligen Feld, nicht mehr
  daneben.
- Eingabefelder haben jetzt 16px Schriftgröße — verhindert, dass iOS Safari
  beim Antippen automatisch reinzoomt.
- Sicherer Innenabstand für Handys mit Notch/Dynamic Island
  (`env(safe-area-inset-*)`), plus enger gefasste Abstände unter 420px
  Breite.
- „Passwort vergessen?“-Link steht jetzt sauber rechtsbündig unter dem
  Formular statt frei zu schweben.

## Was war neu ggü. v5 (weiterhin gültig)

- `install.sh` setzt `wrapper.blade.php` und `LoginFormContainer.tsx` per
  `git checkout` auf den Original-Zustand zurück, **bevor** das neue Theme
  angewendet wird. Dadurch kann nichts von v2/v3/v4/v5 mehr doppelt
  übrig bleiben, egal welche Marker damals genutzt wurden.
- Fallback ohne Git: robustere Marker-Bereinigung als vorher.
- `reset.sh` (neu): setzt die Login-Seite nur zurück, ohne das neue Theme
  zu installieren — falls du erstmal nur aufräumen willst.
- Hintergrund und die Glow-Punkte sind jetzt eine gekoppelte, animierte
  Szene (langsame Bewegung), statt statischer Layer.
- Logo, Karte und Footer kommen nur noch einmal vor.
- `install.sh` leert jetzt automatisch den Cache und baut das Frontend
  selbst (`yarn build:production`), kein manueller Schritt mehr nötig.

## Impressum

Die Platzhalter (Name/Firma, Adresse, E-Mail) in `theme/LoginFormContainer.tsx`
sind noch nicht ausgefüllt — das kann ich nicht für dich erfinden, das muss
mit deinen echten Angaben rein, sonst ist es rechtlich nicht gültig. Suche
nach `HIER DEINEN NAMEN` in der Datei.

## Installation über GitHub

1. Lade diesen Ordner (bzw. das zip) in dein eigenes GitHub-Repo hoch.
2. Auf dem Server:

```bash
cd /root && rm -rf ZypeHost-Theme && \
git clone https://github.com/<DEIN-USER>/<DEIN-REPO>.git ZypeHost-Theme && \
cd ZypeHost-Theme/ZypeHost-Pterodactyl-Theme-v7 && \
chmod +x install.sh reset.sh uninstall.sh && \
bash install.sh
```

Ersetze `<DEIN-USER>/<DEIN-REPO>` mit deinem eigenen Repo-Pfad.

### Nur aufräumen (alte Designs entfernen, ohne neu zu installieren)

```bash
cd /root/ZypeHost-Theme/ZypeHost-Pterodactyl-Theme-v7 && bash reset.sh
```

### Direkt vom Zip auf dem Server (ohne GitHub)

```bash
cd /root && rm -rf ZypeHost-Theme && mkdir ZypeHost-Theme && cd ZypeHost-Theme && \
unzip -o /pfad/zu/ZypeHost-Pterodactyl-Theme-v7.zip && \
cd ZypeHost-Pterodactyl-Theme-v7 && \
chmod +x install.sh reset.sh uninstall.sh && \
bash install.sh
```

## Rückgängig machen

```bash
bash uninstall.sh
```
