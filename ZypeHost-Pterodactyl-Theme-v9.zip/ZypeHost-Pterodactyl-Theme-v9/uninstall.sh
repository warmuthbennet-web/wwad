#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v9-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || { echo 'Kein v9-Backup gefunden. Nutze reset.sh stattdessen.'; exit 1; }
[[ -f "$LATEST/LoginFormContainer.tsx" ]] || { echo 'Backup-Datei fehlt.'; exit 1; }
cp -f "$LATEST/LoginFormContainer.tsx" "$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
if [[ -f "$LATEST/wrapper.blade.php" ]]; then cp -f "$LATEST/wrapper.blade.php" "$PANEL_DIR/resources/views/templates/wrapper.blade.php"; fi
if [[ -d "$LATEST/favicons" ]]; then cp -af "$LATEST/favicons/." "$PANEL_DIR/public/favicons/"; fi
cd "$PANEL_DIR"
php artisan optimize:clear
export NODE_OPTIONS=--openssl-legacy-provider
yarn build:production
echo "ZypeHost v9 entfernt. Backup war: $LATEST"
