#!/usr/bin/env bash
# ZypeHost — clean-only script. Removes ALL ZypeHost login-theme changes
# (any version) and restores the stock Pterodactyl login page. Does NOT
# apply the new v9 design — run install.sh afterwards for that.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost reset] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost reset] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"

cd "$PANEL_DIR"
if [[ -d .git ]]; then
    info "Setze Original-Dateien via git zurück..."
    git checkout -- \
        "resources/views/templates/wrapper.blade.php" \
        "resources/scripts/components/auth/LoginFormContainer.tsx" \
        "public/favicons" "public/favicon.ico" 2>/dev/null || \
        info "Eine der Dateien war schon sauber."
else
    info "Kein Git-Repo — suche letztes Backup..."
    LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | sort | tail -n1 || true)"
    if [[ -n "$LATEST" && -f "$LATEST/LoginFormContainer.tsx" ]]; then
        cp -f "$LATEST/LoginFormContainer.tsx" "$TARGET"
        [[ -f "$LATEST/wrapper.blade.php" ]] && cp -f "$LATEST/wrapper.blade.php" "$WRAPPER"
        [[ -d "$LATEST/favicons" ]] && cp -af "$LATEST/favicons/." "$FAVICON_DIR/"
        info "Aus Backup wiederhergestellt: $LATEST"
    else
        fail "Kein Git-Repo und kein Backup gefunden — kann nicht automatisch zurücksetzen."
    fi
fi

rm -rf "$ASSET_DIR"
info "Alte ZypeHost-Assets entfernt."

php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
command -v yarn >/dev/null 2>&1 && yarn build:production || info "Bitte 'yarn build:production' manuell ausführen."

info "Fertig — Login-Seite ist wieder im Pterodactyl-Originalzustand."
