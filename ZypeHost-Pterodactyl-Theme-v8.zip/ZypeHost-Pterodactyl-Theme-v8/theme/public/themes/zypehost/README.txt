ZypeHost Pterodactyl Theme v6 assets.
background.jpeg = digital-grid background (same asset as v5).
zypehost-logo.png = ZypeHost gamer-dino logo (same asset as v5).

v6 fixes the duplicated card / duplicated Impressum-Rechte-Copyright bug from
earlier installs by hard-resetting wrapper.blade.php and LoginFormContainer.tsx
via git before applying the new single-card layout. See install.sh.
