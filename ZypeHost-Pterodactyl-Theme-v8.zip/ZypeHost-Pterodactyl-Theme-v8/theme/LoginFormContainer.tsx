import React, { forwardRef, useState } from 'react';
import { Form } from 'formik';
import styled, { keyframes } from 'styled-components/macro';
import FlashMessageRender from '@/components/FlashMessageRender';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

/* ---- animation: the background + its glow orbs move together as one
   coupled scene instead of separate static layers ---- */
const drift = keyframes`
    0%   { background-position: 50% 50%, 0% 0%; }
    50%  { background-position: 54% 46%, 100% 100%; }
    100% { background-position: 50% 50%, 0% 0%; }
`;

const orbFloatA = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(26px, -18px) scale(1.08); }
    100% { transform: translate(0, 0) scale(1); }
`;

const orbFloatB = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(-22px, 20px) scale(1.06); }
    100% { transform: translate(0, 0) scale(1); }
`;

const orbFloatC = keyframes`
    0%   { transform: translate(0, 0) scale(1); }
    50%  { transform: translate(16px, 16px) scale(1.1); }
    100% { transform: translate(0, 0) scale(1); }
`;

const Page = styled.main`
    position: fixed;
    inset: 0;
    z-index: 1000;
    width: 100vw;
    min-height: 100dvh;
    overflow-y: auto;
    overflow-x: hidden;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: max(36px, env(safe-area-inset-top)) 22px max(22px, env(safe-area-inset-bottom));
    background:
        linear-gradient(180deg, rgba(1, 9, 13, 0.36), rgba(1, 7, 11, 0.82)),
        url('/themes/zypehost/background.jpeg') center center / cover no-repeat;
    background-size: 140% 140%, cover;
    animation: ${drift} 26s ease-in-out infinite;
    isolation: isolate;

    @media (max-width: 480px) {
        padding-left: 14px;
        padding-right: 14px;
    }

    &::before,
    &::after {
        content: '';
        position: fixed;
        z-index: -1;
        pointer-events: none;
        border-radius: 50%;
        filter: blur(4px);
    }

    &::before {
        top: 12%;
        left: 8%;
        width: 340px;
        height: 340px;
        background: radial-gradient(circle, rgba(0, 213, 255, 0.16), transparent 70%);
        animation: ${orbFloatA} 12s ease-in-out infinite;
    }

    &::after {
        bottom: 10%;
        right: 10%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(210, 31, 43, 0.10), transparent 70%);
        animation: ${orbFloatB} 14s ease-in-out infinite;
    }
`;

const AmbientOrb = styled.div`
    position: fixed;
    z-index: -1;
    top: 55%;
    left: 82%;
    width: 220px;
    height: 220px;
    border-radius: 50%;
    pointer-events: none;
    background: radial-gradient(circle, rgba(0, 150, 255, 0.10), transparent 70%);
    animation: ${orbFloatC} 16s ease-in-out infinite;
`;

const TitleBlock = styled.div`
    width: min(980px, 100%);
    margin-bottom: 18px;
    text-align: center;
    color: #fff;
`;

const BrandMark = styled.div`
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 14px;
    padding: 6px 14px 6px 6px;
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 999px;
    background: rgba(0, 0, 0, .20);
    box-shadow: 0 10px 30px rgba(0,0,0,.16);
    backdrop-filter: blur(14px);
    color: rgba(255,255,255,.9);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .2em;
    text-transform: uppercase;
`;

/* replaces the old plain status-dot: a proper little "Z" wordmark badge
   instead of a generic dot, so the brand strip reads as ZypeHost, not
   as a stock Pterodactyl/falcon mark */
const BrandBadge = styled.span`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    border-radius: 7px;
    background: linear-gradient(135deg, #1674e6, #0b5ec6);
    box-shadow: 0 0 0 1px rgba(255,255,255,.14) inset, 0 4px 10px rgba(11,94,198,.55);
    color: #fff;
    font-size: 13px;
    font-weight: 900;
    letter-spacing: 0;
    text-transform: none;
    position: relative;

    &::after {
        content: '';
        position: absolute;
        top: -2px;
        right: -2px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #00d9ff;
        box-shadow: 0 0 8px rgba(0,217,255,.9);
    }
`;

const Title = styled.h1`
    margin: 0;
    color: #fff;
    font-size: clamp(28px, 4vw, 38px);
    line-height: 1.08;
    font-weight: 800;
    letter-spacing: -.035em;
    text-shadow: 0 8px 28px rgba(0,0,0,.36);
`;

const Subtitle = styled.p`
    margin: 10px auto 0;
    max-width: 620px;
    color: rgba(255,255,255,.70);
    font-size: 13px;
    line-height: 1.6;
`;

const Card = styled.section`
    position: relative;
    width: min(960px, 100%);
    display: grid;
    /* v8: form pane first (left), logo pane second (right) — swapped from v7 */
    grid-template-columns: minmax(0, 1fr) minmax(280px, 39%);
    overflow: hidden;
    border: 1px solid rgba(255,255,255,.54);
    border-radius: 20px;
    background: rgba(255,255,255,.97);
    box-shadow:
        0 34px 100px rgba(0,0,0,.52),
        0 10px 30px rgba(0,0,0,.18);
    backdrop-filter: blur(18px);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #00d9ff, #1674e6 45%, #0b5ec6 75%, #d21f2b);
    }

    @media (max-width: 760px) {
        grid-template-columns: 1fr;
        border-radius: 16px;
    }
`;

const LogoPane = styled.div`
    position: relative;
    min-height: 430px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 34px;
    box-sizing: border-box;
    background:
        radial-gradient(circle at 50% 45%, rgba(255,255,255,1), rgba(248,250,253,1) 64%, rgba(239,244,249,1));
    border-left: 1px solid #e2e8ef;

    &::before {
        content: '';
        position: absolute;
        inset: 28px;
        border: 2px solid rgba(210, 31, 43, .82);
        border-radius: 12px;
        box-shadow:
            inset 0 0 0 1px rgba(210,31,43,.08),
            0 0 30px rgba(210,31,43,.08);
        pointer-events: none;
    }

    &::after {
        content: 'ZypeHost';
        position: absolute;
        left: 50%;
        bottom: 24px;
        transform: translateX(-50%);
        color: #8896a6;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: .34em;
        text-transform: uppercase;
    }

    img {
        position: relative;
        z-index: 1;
        display: block;
        width: min(225px, 82%);
        max-height: 300px;
        object-fit: contain;
        filter: drop-shadow(0 16px 24px rgba(35, 50, 65, .18));
        transition: transform .3s ease;
    }

    &:hover img {
        transform: translateY(-3px) scale(1.015);
    }

    @media (max-width: 760px) {
        min-height: 290px;
        border-left: 0;
        border-top: 1px solid #e2e8ef;
        padding: 24px;

        &::before { inset: 18px; }
        img { width: 180px; max-height: 220px; }
        &::after { bottom: 14px; }
    }
`;

const FormPane = styled.div`
    min-width: 0;
    padding: 42px 44px 36px;
    box-sizing: border-box;

    @media (max-width: 760px) {
        padding: 28px 22px 24px;
    }

    @media (max-width: 420px) {
        padding: 22px 16px 20px;
    }
`;

const FormKicker = styled.div`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    margin-bottom: 12px;
    color: #1674e6;
    font-size: 10.5px;
    font-weight: 800;
    letter-spacing: .22em;
    text-transform: uppercase;

    &::before {
        content: '';
        width: 16px;
        height: 2px;
        border-radius: 2px;
        background: linear-gradient(90deg, #00d9ff, #1674e6);
    }
`;

const FormHeading = styled.div`
    margin-bottom: 28px;

    h2 {
        margin: 0;
        color: #15283b;
        font-size: 28px;
        line-height: 1.2;
        font-weight: 800;
        letter-spacing: -.025em;
    }

    p {
        margin: 8px 0 0;
        color: #748394;
        font-size: 13px;
        line-height: 1.6;
    }
`;

const StyledForm = styled(Form)`
    width: 100%;

    /* v7 fix: the individual field wrappers (username / password / button /
       forgot-password link) were rendering side-by-side instead of stacked,
       causing the label + input + button to visually overlap. Forcing this
       form into a column flex layout guarantees every direct child gets its
       own row no matter what display value it originally had. */
    display: flex;
    flex-direction: column;
    gap: 20px;

    > * {
        width: 100% !important;
        margin: 0 !important;
    }

    /* a wrapper that only contains a single link (e.g. "Forgot password?")
       reads better right-aligned under the button than stretched full-width */
    > div:has(> a:only-child) {
        width: auto !important;
        align-self: flex-end;
    }

    label,
    label span,
    .input-label {
        display: block !important;
        color: #526a80 !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .12em !important;
        text-transform: uppercase;
        margin-bottom: 8px !important;
    }

    input,
    textarea,
    select {
        display: block;
        width: 100% !important;
        min-height: 52px;
        box-sizing: border-box;
        border: 1px solid #d1d9e2 !important;
        border-radius: 10px !important;
        background: #fff !important;
        color: #182a3b !important;
        /* 16px stops iOS Safari from auto-zooming into the field on focus */
        font-size: 16px !important;
        box-shadow: 0 2px 9px rgba(22, 41, 57, .035) !important;
        transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
    }

    input:hover,
    textarea:hover,
    select:hover {
        border-color: #b7c4d1 !important;
    }

    input:focus,
    textarea:focus,
    select:focus {
        border-color: #1268d8 !important;
        box-shadow: 0 0 0 3px rgba(18,104,216,.11) !important;
        outline: 0 !important;
    }

    input::placeholder {
        color: #a3afbb !important;
    }

    button[type='submit'] {
        width: 100% !important;
        min-height: 56px;
        margin-top: 2px;
        border: 0 !important;
        border-radius: 10px !important;
        background: linear-gradient(135deg, #1674e6, #0b5ec6) !important;
        color: #fff !important;
        font-weight: 800 !important;
        letter-spacing: .08em;
        text-transform: uppercase;
        box-shadow: 0 12px 24px rgba(18,104,216,.24) !important;
        transition: transform .16s ease, box-shadow .16s ease, filter .16s ease;
    }

    button[type='submit']:hover {
        transform: translateY(-1px);
        filter: brightness(1.03);
        box-shadow: 0 16px 28px rgba(18,104,216,.29) !important;
    }

    button[type='submit']:active {
        transform: translateY(0);
    }

    a {
        color: #60758a !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .10em !important;
        text-transform: uppercase;
        text-decoration: none !important;
    }

    a:hover {
        color: #1268d8 !important;
    }
`;

const AlertWrap = styled.div`
    margin-bottom: 16px;

    [role='alert'] {
        border-radius: 10px !important;
    }
`;

const Footer = styled.footer`
    width: min(960px, 100%);
    box-sizing: border-box;
    padding: 18px 0 2px;
    text-align: center;
    color: rgba(255,255,255,.74);
    font-size: 11px;
`;

const FooterButtons = styled.div`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;

    button {
        appearance: none;
        border: 1px solid rgba(255,255,255,.24);
        border-radius: 999px;
        padding: 8px 15px;
        background: rgba(0,0,0,.18);
        color: rgba(255,255,255,.88);
        cursor: pointer;
        font: inherit;
        font-weight: 700;
        letter-spacing: .04em;
        backdrop-filter: blur(10px);
        transition: background .16s ease, border-color .16s ease, transform .16s ease;
    }

    button:hover {
        background: rgba(15, 119, 212, .42);
        border-color: rgba(255,255,255,.44);
        transform: translateY(-1px);
    }
`;

const Copyright = styled.div`
    margin-top: 9px;
    color: rgba(255,255,255,.54);
    letter-spacing: .03em;
`;

const ModalOverlay = styled.div`
    position: fixed;
    inset: 0;
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 22px;
    box-sizing: border-box;
    background: rgba(0, 7, 12, .72);
    backdrop-filter: blur(9px);
`;

const Modal = styled.div`
    width: min(720px, 100%);
    max-height: min(80vh, 760px);
    overflow: auto;
    border: 1px solid rgba(255,255,255,.58);
    border-radius: 16px;
    background: rgba(255,255,255,.98);
    color: #24384b;
    box-shadow: 0 36px 100px rgba(0,0,0,.48);
`;

const ModalHeader = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 18px 20px;
    border-bottom: 1px solid #e7edf3;

    h2 {
        margin: 0;
        color: #142b40;
        font-size: 21px;
        font-weight: 800;
    }

    button {
        width: 34px;
        height: 34px;
        border: 0;
        border-radius: 9px;
        background: #eef3f7;
        color: #5c6f80;
        cursor: pointer;
        font-size: 23px;
        line-height: 1;
    }
`;

const ModalBody = styled.div`
    padding: 22px;
    font-size: 14px;
    line-height: 1.7;

    h3 {
        margin: 0 0 8px;
        color: #19344e;
        font-size: 17px;
    }

    p { margin: 0 0 14px; }
`;

/* This component renders exactly ONE card, ONE logo and ONE footer.
   There is no DOM-injection fallback and no leftover markup from older
   theme versions living anywhere else in this file — install.sh resets
   wrapper.blade.php via git before this file is written, so nothing else
   on the page can duplicate what is rendered here. */
export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const [modal, setModal] = useState<'impressum' | 'rechte' | null>(null);

    const closeModal = () => setModal(null);

    return (
        <Page>
            <AmbientOrb />
            <TitleBlock>
                <BrandMark><BrandBadge>Z</BrandBadge> ZypeHost</BrandMark>
                <Title>{title || 'Login to Continue'}</Title>
                <Subtitle>Secure access to your hosting control panel.</Subtitle>
            </TitleBlock>

            <Card>
                <FormPane>
                    <FormHeading>
                        <FormKicker>Account Access</FormKicker>
                        <h2>Welcome back</h2>
                        <p>Sign in with your ZypeHost account to continue.</p>
                    </FormHeading>

                    <AlertWrap>
                        <FlashMessageRender />
                    </AlertWrap>

                    <StyledForm {...props} ref={ref}>
                        {props.children}
                    </StyledForm>
                </FormPane>

                <LogoPane>
                    <img src={'/themes/zypehost/zypehost-logo.png'} alt={'ZypeHost'} />
                </LogoPane>
            </Card>

            <Footer>
                <FooterButtons>
                    <button type={'button'} onClick={() => setModal('impressum')}>Impressum</button>
                    <button type={'button'} onClick={() => setModal('rechte')}>Rechte</button>
                </FooterButtons>
                <Copyright>Copyright ZypeHost 26/27 ©️</Copyright>
            </Footer>

            {modal && (
                <ModalOverlay onMouseDown={closeModal}>
                    <Modal onMouseDown={(event) => event.stopPropagation()}>
                        <ModalHeader>
                            <h2>{modal === 'impressum' ? 'Impressum' : 'Rechte'}</h2>
                            <button type={'button'} aria-label={'Close'} onClick={closeModal}>×</button>
                        </ModalHeader>
                        <ModalBody>
                            {modal === 'impressum' ? (
                                <>
                                    <h3>Impressum</h3>
                                    <p><strong>Angaben gemäß § 5 DDG</strong><br />
                                        Bennet Warmuth<br />
                                        Rosenanger 10<br />
                                        15745 Wildau<br />
                                        Deutschland</p>
                                    <p><strong>Kontakt</strong><br />
                                        E-Mail: <a href="mailto:info@zypehost.de" style={{ color: '#1268d8' }}>info@zypehost.de</a></p>
                                    <p><strong>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</strong><br />
                                        Bennet Warmuth<br />
                                        Rosenanger 10<br />
                                        15745 Wildau<br />
                                        Deutschland</p>
                                </>
                            ) : (
                                <>
                                    <h3>ZypeHost</h3>
                                    <p>Informationen zu Marken, Grafiken und eigenen Inhalten von ZypeHost werden hier veröffentlicht.</p>
                                    <p>Pterodactyl ist ein eigenständiges Open-Source-Projekt. Diese Login-Darstellung ist ein eigenes ZypeHost-Branding.</p>
                                    <p>Drittanbieter-Inhalte bleiben ihren jeweiligen Rechteinhabern zugeordnet.</p>
                                </>
                            )}
                        </ModalBody>
                    </Modal>
                </ModalOverlay>
            )}
        </Page>
    );
});
